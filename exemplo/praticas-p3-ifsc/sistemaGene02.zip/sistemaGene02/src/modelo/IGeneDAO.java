package modelo;

public interface IGeneDAO {
	//FALTA O METODOS 

}
